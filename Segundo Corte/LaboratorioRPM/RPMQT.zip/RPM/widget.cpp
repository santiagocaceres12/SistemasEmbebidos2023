#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    cont++;
    qDebug()<< "Started";

            foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
                QString pname = serialPortInfo.portName();
                int pid = serialPortInfo.productIdentifier();
                int vid = serialPortInfo.vendorIdentifier();
                if(pid == product && vid == vendor){
                    abrirPuerto(pname);
                    connect(ttl, SIGNAL(readyRead()),this, SLOT(readSerial()));
                    break;
                }
            }
}

Widget::~Widget()
{
    delete ui;
}

void Widget::abrirPuerto(QString nombre)
{
    qDebug()<<nombre;
    ttl = new QSerialPort(this);
    ttl->setPortName(nombre);
    ttl->open(QSerialPort::ReadWrite);
    ttl->setBaudRate(QSerialPort::Baud115200);
    ttl->setDataBits(QSerialPort::Data8);
    ttl->setParity(QSerialPort::NoParity);
    ttl->setStopBits(QSerialPort::OneStop);
    ttl ->setFlowControl(QSerialPort::NoFlowControl);

}


void Widget::readSerial()
{
    QByteArray buffer = ttl->readAll();
    serialData.append(buffer);
    qDebug() << serialData;
    if(serialData.at(0) == 0x02 && serialData.at(serialData.at(1)-1)==0x3A){
        qDebug()<<"Paquete con cabeza y cola iguales";
       // calculate(serialData);
        if(verify_xor(serialData,serialData.length(),serialData.at(serialData.length()-2)) == ACK) {
            qDebug()<<"xor igual";
            calculate(buffer);
            serialData.clear();
        }
    }

    qDebug()<<"---------------------------------------------";
}

uint8_t Widget::xor_operation(QByteArray buffer, uint32_t lenght) {
    uint8_t *datos;
    uint8_t XOR = 0;
    datos = (uint8_t*)malloc(lenght-2);
    for(uint32_t i = 0 ; i < lenght - 2 ; i++){
        datos[i] = (uint8_t)buffer.at(i);
        XOR = XOR ^ datos[i];
    }
    free(datos);
    return XOR;
}


float Widget::bytes_float(uint8_t byte_1,uint8_t byte_2,uint8_t byte_3,uint8_t byte_4){
    uint32_t u = ((uint32_t)byte_1) | ((uint32_t)byte_2 << 8) | ((uint32_t)byte_3 << 16) | ((uint32_t)byte_4 << 24);
    return *(float*) & u;
}

uint8_t Widget::calculate(QByteArray buffer) {

    time = bytes_float(buffer.at(2),buffer.at(3),buffer.at(4),buffer.at(5));
    pulse = bytes_float(buffer.at(6),buffer.at(7),buffer.at(8),buffer.at(9));
    //qDebug()<<time;
    qDebug()<<pulse;

    if (pulse != 0) {
            rpm=(1000.0*1000.0*60.0)/(2.0*pulse*100.0);
            if(rpm > 0){
                textoConcatenado = ',' + QString::number(rpm);
                ui->textEdit->append(textoConcatenado);
            }

        } else {
            rpm = 0;
        }

    //rpm=(pulse*1000.0*60.0)/(20*2);
    if (rpm>rpmMax){
        rpmMax=rpm;
    }
    if(RunStop == 0){
        timeStop += (1000.0*1000.0*pulse)/60.0;
        ui->tiempoParadaLabel->setText("Tiempo de parada real:" + QString::number(timeStop));
    }

    ui->rpmActualLabel->setText("RPM Actual:" + QString::number(rpm));
    ui->rpmMaxLabel->setText("RPM max:" + QString::number(rpmMax));
}

uint8_t Widget::verify_xor(QByteArray buffer, uint32_t length, uint8_t recieved_xor){

    if(xor_operation(buffer,length) == recieved_xor){
        return ACK;
    } else {
        return NACK;
    }
}



QByteArray Widget::createDataBuffer(){
    uint8_t packageData[4];
    uint32_t data = *(uint32_t*) &rpm;
    packageData[0] = data & 0x000000FF;
    packageData[1] = (data & 0x0000FF00) >> 8;
    packageData[2] = (data & 0x00FF0000) >> 16;
    packageData[3] = (data & 0xFF000000) >> 24;


    dataBuffer.append(packageData[0]);
    dataBuffer.append(packageData[1]);
    dataBuffer.append(packageData[2]);
    dataBuffer.append(packageData[3]);

    return dataBuffer;
}


QByteArray Widget::create_protocol(uint8_t operation)
{
    QByteArray protocol;
    QByteArray dataRPM = createDataBuffer();
    uint8_t total_len = overhead + 1;
    protocol.append(0x02);
    protocol.append(total_len);
    protocol.append(0x01);
    /*for (int i = 0; i < dataRPM.length(); ++i) {
      protocol.append(dataRPM.at(i));
    }*/
    protocol.append(operation); // OPERATION
    protocol.append(xor_operation(protocol,total_len));
    protocol.append(0x3A);
    qDebug()<<protocol;
    dataRPM.clear();
    return protocol;
}


void Widget::on_startButton_clicked()
{
    constantStart = 0x11;
    RunStop = 1;
    timeStop = 0;
    ui->tiempoParadaLabel->setText("Tiempo de parada real:" + QString::number(timeStop));
    ttl->write(create_protocol(constantStart));
}


void Widget::on_stopButton_clicked()
{
    constantStop = 0x12;
    RunStop = 0;
    ttl->write(create_protocol(constantStop));
}

void Widget::saveDataRMP(float datos){
    mytxt = fopen("C:/Users/Laura Blanco/Desktop/datosRPM.txt", "w");
    if(mytxt == NULL){
       mytxt = fopen("C:/Users/Laura Blanco/Desktop/datosRPM.txt", "w+");
    }else{
        fprintf(mytxt,"RPM: %f\n", datos);
        fclose(mytxt);
    }
}

void Widget::on_pushButton_clicked()
{

}

