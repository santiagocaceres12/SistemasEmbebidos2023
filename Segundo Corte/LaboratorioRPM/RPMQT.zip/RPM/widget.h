#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_startButton_clicked();

    void on_stopButton_clicked();

    uint8_t verify_xor(QByteArray buffer, uint32_t length, uint8_t recieved_xor);

    uint8_t xor_operation(QByteArray buffer, uint32_t length);

    float bytes_float(uint8_t byte_1,uint8_t byte_2,uint8_t byte_3,uint8_t byte_4);

    uint8_t calculate(QByteArray buffer);

    QByteArray create_protocol(uint8_t operation);

    void readSerial();

    void on_pushButton_clicked();

    QByteArray createDataBuffer();

    void saveDataRMP(float datos);

private:
    Ui::Widget *ui;
    uint32_t cont =0;
    QSerialPort *ttl=nullptr;
    QByteArray serialData;
    int vendor=1155;
    int product=22336;
    void abrirPuerto(QString nombre);
    uint8_t overhead = 5;
    const uint8_t ACK = 0x59;
    const uint8_t NACK = 0x4E;
    QByteArray total_buffer;
    QByteArray dataBuffer;
    uint8_t cont2 = 0;
    uint32_t timeStop = 1;
    uint8_t RunStop = 1;
    float pulse;
    float time;
    float rpm;
    float rpmMax = 0;
    float constantStart;
    float constantStop;
    FILE *mytxt;
    float dataEntrada;
    QString texto;
    QString textoConcatenado;
};
#endif // WIDGET_H
